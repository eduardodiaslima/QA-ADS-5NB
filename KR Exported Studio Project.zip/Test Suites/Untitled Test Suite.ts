<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Untitled Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>bb3ed27b-102d-4b4f-b507-118775da4e8f</testSuiteGuid>
   <testCaseLink>
      <guid>db6537e4-5769-4fd7-8dc9-27f674b2f06b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Untitled Test Suite/Teste de Usuabilidade aula 23/04/2025</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    